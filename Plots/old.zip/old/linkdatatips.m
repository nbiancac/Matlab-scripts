function linkdatatips(hg,N)
% LINKDATATIPS - creates linked datatips at same location in all plots and 
% keeps them linked as the user moves the datatip around the first plot.
% This function is valid only for plots formed by image, imagesc, mesh,meshc
% pcolor, surf and surfc.
%
% linkdatatips(hg,N)
% hg is a vector of handles to the plots.
% N = maximum digits of precision displayed.See num2str. N defaults to 2
% To restore default unlinked behavior, call with no argument
% To shift the primary datatip focus to the kth plot, call again as
% linkdatatips(hg(k))
%
% Default behavior of the datatip is SnapToDataVertex. This avoids interpolation
%errors when surfacces have sharp discontinuities. Interpolation can be
%enabled by right clicking on the datatip and setting Selection Style to
%Mouse Position
% 
% EXAMPLE:
% z = peaks(50);
% figure
% h(1) = imagesc(z);
% figure
% subplot 121
% h(2) = surf(z.^2);
% subplot 122
% h(3)=mesh(z+3);
% linkdatatips(h);
%
%
%   See also MAKEDATATIP, DATACURSORMODE

%Author: Iram J. Weinstein
%Email: iweinstein@ieee.org
%Creation Date: 26-Mar-2010
%Modified: 17-May-2010 with several changes
%1. Default behavior changed to SnapToDataVertex
%2. Feature where primary datatip can be moved to anothr plot added
%Modified: $Date$

persistent hDataCursorMgr fig hgsave
if nargin == 0
    if ~isempty(hDataCursorMgr) && ishandle(fig(1))
        %check to see if primary figure is still open
        %restore datatip behavior to default
        removeAllDataCursors(hDataCursorMgr)
        myupdatefcn('deleteDatatips');
        set(hDataCursorMgr,'Enable','off','UpdateFcn',[]);
        clear hDataCursorMgr
    end
    return
end
%check to see that all are images or surfaceplots
if any(~validhandle(hg))
    error('LINKDATATIPS:InvalidObjectType',...
        'bOnly image and surfaceplot objects are valid targets for datatips.');
end

%see if the call is for a vector of plot handles, in which case it is a
%first call, or just one handle in which case the user is trying to move
%the focus
if ~isscalar(hg)
    hgsave=hg;
else
    n=find(hgsave==hg);
    hg=hgsave([n:end 1:n-1]);
    linkdatatips;
end
    
%start fresh each time linkdatatips is called
myupdatefcn('clear');

if nargin == 1,N = 2;end

%find the figure handles for hg. Note possibly the plots are not in
%separate figures
for k = 1:length(hg)
    fig(k) = ancestor(hg(k),'figure');
end

%put the figure handles and the plot handles into figure 1 userdata so they
%will be accessible from the update function
ud.fig = fig;
ud.hg = hg;
ud.N = N;

set(fig(1),'UserData',ud);
hDataCursorMgr = datacursormode(fig(1));
set( hDataCursorMgr,'DisplayStyle','datatip',...
    'SnapToDataVertex','on','Enable','on',...
    'Updatefcn', @myupdatefcn);
end

function txt = myupdatefcn(empt,event_obj)
%This function is called every time the primary datatip is moved. It checks
%to see which handles are still valid and then updates the datatips in the
%linked plots.
persistent X Y Z hDatatip
if strcmp(empt,'clear')
    clear X Y X hDatatip
    return
end
if  strcmp(empt,'deleteDatatips')
    for k = 1:length(hDatatip)
        if ~isempty(hDatatip{k})
            try %error if fig deletedure has been
                hDatatip{k}.delete;
            end
        end
    end
    return
end
ud = get(gcf,'UserData');
hg = ud.hg;
fig = ud.fig;
N = ud.N;

if isempty(X)
    X = get(hg(1),'XData');
    Y = get(hg(1),'YData');
    plottype = validhandle(hg); %at this point all are guaranteed valid
    for k = 1:length(hg)
        if plottype(k) == 1
            Z(k,:,:) = get(hg(k),'ZData');
        else
            Z(k,:,:) = get(hg(k),'CData');
        end
    end
    X = linspace(X(1),X(end),size(Z,3));
    Y = linspace(Y(1),Y(end),size(Z,2));
    [X,Y] = meshgrid(X,Y);
    hDatatip = cell(1,length(hg));
end

%now setup the datatips
pos = get(event_obj,'Position');
plottype = validhandle(hg); %plots may have been closed or changed so check again for valid
validplots = 1:length(hg);
validplots(plottype == 0) = [];
for k = validplots
    z(k) = interp2(X,Y,squeeze(Z(k,:,:)),pos(1),pos(2));
end

txt = {['X=' num2str(pos(1),N)],['Y=' num2str(pos(2),N)],['Z=' num2str(z(1),N)]};

% Link datatips
for k = validplots(2:end)
    if ~isempty(hDatatip{k})
        hDatatip{k}.delete;
    end
    hDatatip{k} = newDatatip(hg(k),[pos z(k)],N);
end
end

function hDatatip = newDatatip(hObj,pos,N)
%this serves to give an x,y,z datatip for image plots
txt = {['X=' num2str(pos(1),N)],['Y=' num2str(pos(2),N)],['Z=' num2str(pos(3),N)]};
% Get handle to datacursor mode object
hDataCursorMgr = datacursormode(ancestor(hObj,'figure'));
% Create datatip
hDatatip = createDatatip(hDataCursorMgr, hObj);
set(get(hDatatip,'DataCursor'), 'TargetPoint',pos)
% Specify datatip properties
set(hDatatip,'Position',pos(1:2),'String',txt)
end

function valid = validhandle(hg)
%check to see that the plots are valid types
%also distinguish between 3D surfaces, for which valiad returns 1
%and flat ones,specifically image and pcolor for which vlaid returns 2.
%Note that a pcolor is a surf with z==0.
handleObj = handle(hg);
valid = ones(size(hg));
for k = 1:length(handleObj)
    if ~(isa(handleObj(k),'hg.image')...
            || isa(handleObj(k),'surface')...
            || isa(handleObj(k),'graph3d.surfaceplot'))
        valid(k) = 0;
    else
        if strcmp(get(hg(k),'type'),'image')
            valid(k) = 2;
        else
            ztest = get(hg(k),'Zdata');
            if ~any(ztest(:))
                valid(k) = 2;
            end
        end
    end
end
end

